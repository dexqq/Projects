//pages/add_device.php
<?php
include_once '../config/config.php';
include_once '../classes/Database.php';
include_once '../classes/Manufacturer.php';
include_once '../classes/Device.php';

$database = new Database();
$db = $database->getConnection();

$manufacturer = new Manufacturer($db);
$device = new Device($db);

if ($_POST) {
    $device->manufacturer_id = $_POST['manufacturer_id'];
    $device->model = $_POST['model'];
    $device->price = $_POST['price'];
    $device->year = $_POST['year'];

    if ($device->create()) {
        echo "<div>Device was created.</div>";
    } else {
        echo "<div>Unable to create device.</div>";
    }
}

$manufacturers = $manufacturer->readAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Device</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="add_device.php">Add Device</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <form action="add_device.php" method="post">
            <label for="manufacturer_id">Manufacturer:</label>
            <select name="manufacturer_id" required>
                <?php while ($row = $manufacturers->fetch(PDO::FETCH_ASSOC)): ?>
                    <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
                <?php endwhile; ?>
            </select><br>
            <label for="model">Model:</label>
            <input type="text" name="model" required><br>
            <label for="price">Price:</label>
            <input type="text" name="price" required><br>
            <label for="year">Year:</label>
            <input type="text" name="year" required><br>
            <button type="submit">Add Device</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 Mobile Devices</p>
    </footer>
</body>
</html>
