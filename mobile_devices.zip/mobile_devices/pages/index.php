//pages/index.php
<?php
include_once '../config/config.php';
include_once '../classes/Database.php';
include_once '../classes/Device.php';

$database = new Database();
$db = $database->getConnection();

$device = new Device($db);
$devices = $device->readAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobile Devices</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="add_device.php">Add Device</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h1>Mobile Devices</h1>
        <table>
            <thead>
                <tr>
                    <th>Manufacturer</th>
                    <th>Model</th>
                    <th>Price</th>
                    <th>Year</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $devices->fetch(PDO::FETCH_ASSOC)): ?>
                    <tr>
                        <td><?= $row['manufacturer'] ?></td>
                        <td><?= $row['model'] ?></td>
                        <td><?= $row['price'] ?></td>
                        <td><?= $row['year'] ?></td>
                        <td><?= $row['created_at'] ?></td>
                        <td>
                            <a href="edit_device.php?id=<?= $row['id'] ?>">Edit</a>
                            <a href="delete_device.php?id=<?= $row['id'] ?>">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
    <footer>
        <p>&copy; 2024 Mobile Devices</p>
    </footer>
</body>
</html>
