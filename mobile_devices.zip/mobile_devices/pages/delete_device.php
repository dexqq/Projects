//pages/delete_device.php
<?php
include_once '../config/config.php';
include_once '../classes/Database.php';
include_once '../classes/Device.php';

$database = new Database();
$db = $database->getConnection();

$device = new Device($db);
$device->id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Record ID not found.');

if ($device->delete()) {
    echo "<div>Device was deleted.</div>";
} else {
    echo "<div>Unable to delete device.</div>";
}
?>
<a href="index.php">Back to Home</a>
