// lasses/Device.php
<?php
class Device {
    private $conn;
    private $table_name = "devices";

    public $id;
    public $manufacturer_id;
    public $model;
    public $price;
    public $year;
    public $created_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Create device
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " SET manufacturer_id=:manufacturer_id, model=:model, price=:price, year=:year";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":manufacturer_id", $this->manufacturer_id);
        $stmt->bindParam(":model", $this->model);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":year", $this->year);
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Read all devices
    public function readAll() {
        $query = "SELECT d.id, m.name as manufacturer, d.model, d.price, d.year, d.created_at
                  FROM " . $this->table_name . " d
                  LEFT JOIN manufacturer m ON d.manufacturer_id = m.id
                  ORDER BY d.created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Read one device
    public function readOne() {
        $query = "SELECT manufacturer_id, model, price, year, created_at FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $this->manufacturer_id = $row['manufacturer_id'];
            $this->model = $row['model'];
            $this->price = $row['price'];
            $this->year = $row['year'];
            $this->created_at = $row['created_at'];
        }
    }

    // Update device
    public function update() {
        $query = "UPDATE " . $this->table_name . " SET manufacturer_id = :manufacturer_id, model = :model, price = :price, year = :year WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':manufacturer_id', $this->manufacturer_id);
        $stmt->bindParam(':model', $this->model);
        $stmt->bindParam(':price', $this->price);
        $stmt->bindParam(':year', $this->year);
        $stmt->bindParam(':id', $this->id);
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Delete device
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>
