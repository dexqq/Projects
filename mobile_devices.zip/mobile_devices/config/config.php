//config/config.php
<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'mobile_devices_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Autoload klasa
spl_autoload_register(function ($class_name) {
    include __DIR__ . '/../classes/' . $class_name . '.php';
});

// Funkcija za povezivanje sa bazom
function getDBConnection() {
    try {
        $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
        return null;
    }
}
?>
